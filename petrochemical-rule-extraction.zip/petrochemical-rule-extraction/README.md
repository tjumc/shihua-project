# petrochemical-rule-extraction

用于从石化项目目录中的 PDF、DOC/DOCX、TXT、XLS/XLSX 文件中抽取“工艺规范规则”和“调度经验规则”。

## 安装

```bash
mkdir -p ~/.claude/skills
cp -r petrochemical-rule-extraction ~/.claude/skills/
```

## 内置模板

```text
templates/rule_summary_template.xlsx
```

该模板包含两个空白子表，已删除原始内容，但保留格式和列头：

- `2、工艺规范规则（120条）`
- `4、调度经验规则（90条）`

两个子表字段顺序均为：

```text
规则编号, 规则名称, 知识类型, 子类型, 适用范围, 规则内容, 来源文件, 具体页码, 原文内容, JSON, 备注
```

## Claude Code 调用示例

```text
请使用 petrochemical-rule-extraction skill，扫描 ./project_docs，输出规则到 ./rule_output。
要求使用内置 Excel 模板，不生成 mask、置信度、人工核验或人工核对字段。
```
